"""LSTM для предсказания следующего syscall'а по предыдущим N (next-token
prediction), плюс функции подсчёта anomaly score по выходу модели.

Архитектура: отдельный Embedding на каждый категориальный признак (syscall,
process, direction, опционально arg_count-bucket) — конкатенация — LSTM —
линейный слой, проецирующий скрытое состояние КАЖДОГО шага в логиты по
словарю syscall'ов (в отличие от классификации целого окна, здесь нужен
выход на каждом шаге последовательности, не только последний).
"""

from dataclasses import asdict, dataclass

import torch
import torch.nn.functional as F
from torch import nn

import config
from data import FEATURE_NAMES


@dataclass(frozen=True)
class ModelHParams:
    """Всё, что нужно, чтобы однозначно восстановить архитектуру SyscallLSTM
    (в отличие от seq_len/score_method/threshold — это НЕ гиперпараметры
    архитектуры, а про данные/детекцию, поэтому их здесь нет).

    Ключевая причина существования этого класса: раньше SyscallLSTM.__init__
    читал эти значения напрямую из живого config.py, а чекпоинт хранил их
    просто "на память", не как источник истины. Если между обучением и
    инференсом (или между двумя RESUME-запусками) поменять, например,
    config.HIDDEN_DIM — модель конструировалась под НОВЫЙ config, а веса
    в чекпоинте были под СТАРЫЙ, и load_state_dict падал с ошибкой
    размерности. Теперь чекпоинт — источник истины при загрузке/дообучении,
    config.py используется только при обучении "с нуля".
    """

    embed_dim_syscall: int
    embed_dim_process: int
    embed_dim_direction: int
    embed_dim_arg_count: int
    use_arg_count_feature: bool
    hidden_dim: int
    num_layers: int
    dropout: float

    @classmethod
    def from_config(cls) -> "ModelHParams":
        return cls(
            embed_dim_syscall=config.EMBED_DIM_SYSCALL,
            embed_dim_process=config.EMBED_DIM_PROCESS,
            embed_dim_direction=config.EMBED_DIM_DIRECTION,
            embed_dim_arg_count=config.EMBED_DIM_ARG_COUNT,
            use_arg_count_feature=config.USE_ARG_COUNT_FEATURE,
            hidden_dim=config.HIDDEN_DIM,
            num_layers=config.NUM_LAYERS,
            dropout=config.DROPOUT,
        )

    @classmethod
    def from_checkpoint(cls, checkpoint: dict) -> "ModelHParams":
        if "hparams" in checkpoint:
            return cls(**checkpoint["hparams"])
        # Обратная совместимость со старыми чекпоинтами (сохранены плоско,
        # без единого ключа "hparams") — поля называются так же.
        return cls(
            embed_dim_syscall=checkpoint["embed_dim_syscall"],
            embed_dim_process=checkpoint["embed_dim_process"],
            embed_dim_direction=checkpoint["embed_dim_direction"],
            embed_dim_arg_count=checkpoint["embed_dim_arg_count"],
            use_arg_count_feature=checkpoint["use_arg_count_feature"],
            hidden_dim=checkpoint["hidden_dim"],
            num_layers=checkpoint["num_layers"],
            dropout=checkpoint["dropout"],
        )

    def to_dict(self) -> dict:
        return asdict(self)


class SyscallLSTM(nn.Module):
    """vocab_sizes: {"syscall": N, "process": N, "direction": N, ["arg_count": N]}
    (ключ "arg_count" присутствует, только если hparams.use_arg_count_feature=True
    — в этом случае он должен быть последним в FEATURE_NAMES-порядке входа).

    hparams: если не передан — берётся из текущего config.py (обучение с
    нуля). При загрузке/дообучении из чекпоинта ВСЕГДА передавайте
    ModelHParams.from_checkpoint(checkpoint) явно — не полагайтесь на
    default, иначе вернётся тот же баг, который это исправляет. Удобнее
    использовать SyscallLSTM.from_checkpoint(...) ниже, он делает это сам.
    """

    def __init__(self, vocab_sizes: dict[str, int], hparams: ModelHParams | None = None) -> None:
        super().__init__()

        self.hparams = hparams if hparams is not None else ModelHParams.from_config()

        self.feature_order = list(FEATURE_NAMES)  # ["syscall", "process", "direction"]
        if self.hparams.use_arg_count_feature:
            self.feature_order.append("arg_count")

        embed_dims = {
            "syscall": self.hparams.embed_dim_syscall,
            "process": self.hparams.embed_dim_process,
            "direction": self.hparams.embed_dim_direction,
            "arg_count": self.hparams.embed_dim_arg_count,
        }

        self.embeddings = nn.ModuleDict()
        for name in self.feature_order:
            emb = nn.Embedding(vocab_sizes[name], embed_dims[name], padding_idx=0)
            self.embeddings[name] = emb

        total_embed_dim = sum(embed_dims[name] for name in self.feature_order)

        self.lstm = nn.LSTM(
            input_size=total_embed_dim,
            hidden_size=self.hparams.hidden_dim,
            num_layers=self.hparams.num_layers,
            batch_first=True,
            dropout=self.hparams.dropout if self.hparams.num_layers > 1 else 0.0,
        )
        self.output = nn.Linear(self.hparams.hidden_dim, vocab_sizes["syscall"])

    @classmethod
    def from_checkpoint(cls, checkpoint: dict, device: torch.device | str = "cpu") -> "SyscallLSTM":
        """Единая точка восстановления модели из чекпоинта: архитектура
        берётся из checkpoint (через ModelHParams), а не из живого config.py."""
        hparams = ModelHParams.from_checkpoint(checkpoint)
        model = cls(checkpoint["vocab_sizes"], hparams=hparams).to(device)
        model.load_state_dict(checkpoint["model_state"])
        return model

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: [batch, seq_len, num_features] (порядок фич — self.feature_order).
        Возвращает логиты [batch, seq_len, vocab_size_syscall]."""
        embedded = [
            self.embeddings[name](x[:, :, i]) for i, name in enumerate(self.feature_order)
        ]
        combined = torch.cat(embedded, dim=-1)  # [batch, seq_len, total_embed_dim]
        hidden_states, _ = self.lstm(combined)  # [batch, seq_len, hidden_dim]
        logits = self.output(hidden_states)  # [batch, seq_len, vocab_size_syscall]
        return logits


def compute_step_scores(logits: torch.Tensor, targets: torch.Tensor, method: str = "nll", top_k: int = 5) -> torch.Tensor:
    """Anomaly score НА КАЖДЫЙ ШАГ (без агрегации по окну) [batch, seq_len].

    method:
        "nll"   — -log(P(правильный syscall)) на каждом шаге. Высокий score
                  = модель не верила в то, что реально произошло.
        "top_k" — 1 на шагах, где истинный syscall НЕ попал в top-k
                  предсказанных моделью (классический STIDE-подход).
    """
    if method == "nll":
        log_probs = F.log_softmax(logits, dim=-1)  # [batch, seq, vocab]
        target_log_probs = log_probs.gather(-1, targets.unsqueeze(-1)).squeeze(-1)  # [batch, seq]
        return -target_log_probs
    elif method == "top_k":
        topk_indices = logits.topk(top_k, dim=-1).indices  # [batch, seq, k]
        hit = (topk_indices == targets.unsqueeze(-1)).any(dim=-1)  # [batch, seq] bool
        return (~hit).float()
    else:
        raise ValueError(f"Неизвестный method={method!r}, ожидалось 'nll' или 'top_k'")


def aggregate_window_scores(step_scores: torch.Tensor, window_agg: str = "max", window_agg_quantile: float = 0.9) -> torch.Tensor:
    """Свёртка step_scores [batch, seq_len] в один score на окно [batch].

    "max"      — худший (самый аномальный) шаг окна. Чувствителен к атакам
                 ЛЮБОЙ длины внутри окна (даже 1 шаг), но может насыщаться,
                 если единичные-но-легитимные выбросы NLL встречаются почти
                 в каждом окне независимо от того, атака это или нет —
                 тогда разделяющая способность падает (см. AUC).
    "quantile" — window_agg_quantile-й перцентиль step_scores (нужен
                 минимум (1-quantile)-доля "плохих" шагов в окне).
    "mean"     — среднее по всем шагам окна. Менее чувствителен к единичным
                 всплескам, зато требует, чтобы аномальность была "размазана"
                 по значительной части окна, а не сосредоточена в паре шагов.
    """
    if window_agg == "max":
        return step_scores.max(dim=1).values  # [batch]
    elif window_agg == "quantile":
        return step_scores.quantile(window_agg_quantile, dim=1)  # [batch]
    elif window_agg == "mean":
        return step_scores.mean(dim=1)  # [batch]
    else:
        raise ValueError(f"Неизвестный window_agg={window_agg!r}, ожидалось 'max', 'quantile' или 'mean'")


def compute_window_scores(
    logits: torch.Tensor,
    targets: torch.Tensor,
    method: str = "nll",
    top_k: int = 5,
    window_agg: str = "max",
    window_agg_quantile: float = 0.9,
) -> torch.Tensor:
    """compute_step_scores + aggregate_window_scores за один вызов (для
    случаев, когда нужна только ОДНА конкретная агрегация — обучение,
    калибровка порога). Если нужно сравнить несколько агрегаций на одних и
    тех же логитах (диагностика) — вызывайте compute_step_scores один раз и
    прогоняйте aggregate_window_scores несколько раз, см.
    train.quick_test_evaluation.
    """
    step_scores = compute_step_scores(logits, targets, method=method, top_k=top_k)
    return aggregate_window_scores(step_scores, window_agg=window_agg, window_agg_quantile=window_agg_quantile)